package com.example.flashsalehunter

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class Product(val name: String, val url: String, val targetPrice: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FlashSaleApp() } }
    }
}

@Composable
fun FlashSaleApp() {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("flashsale_hunter", android.content.Context.MODE_PRIVATE)
    }
    val products = remember {
        mutableStateListOf<Product>().apply {
            val raw = prefs.getString("products", "[]") ?: "[]"
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    add(Product(item.getString("name"), item.getString("url"), item.getLong("target")))
                }
            }
        }
    }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun persist() {
        val arr = JSONArray()
        products.forEach {
            arr.put(JSONObject().put("name", it.name).put("url", it.url).put("target", it.targetPrice))
        }
        prefs.edit().putString("products", arr.toString()).apply()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("⚡ FlashSale Hunter", style = MaterialTheme.typography.headlineMedium)
        Text("Asisten berburu promo Shopee", style = MaterialTheme.typography.bodyMedium)

        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Nama produk") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("URL produk Shopee") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = target, onValueChange = { target = it.filter(Char::isDigit) },
            label = { Text("Harga target (Rp)") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(
            onClick = {
                val price = target.toLongOrNull()
                val uri = runCatching { Uri.parse(url.trim()) }.getOrNull()
                val validUrl = uri != null && uri.scheme == "https" &&
                    uri.host in setOf("shopee.co.id", "www.shopee.co.id")
                if (name.isBlank() || price == null || price <= 0 || !validUrl) {
                    error = "Isi nama, harga target, dan URL https://shopee.co.id yang valid."
                } else {
                    products.add(Product(name.trim(), url.trim(), price))
                    persist()
                    name = ""; url = ""; target = ""; error = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Tambah produk incaran") }

        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error)
        }

        HorizontalDivider()
        Text("Produk incaran (${products.size})", style = MaterialTheme.typography.titleLarge)

        if (products.isEmpty()) {
            Text("Belum ada produk. Tambahkan tautan produk Shopee di atas.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products) { product ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(product.name, style = MaterialTheme.typography.titleMedium)
                            Text("Harga target: Rp${"%,d".format(java.util.Locale("id", "ID"), product.targetPrice)}")
                            Text(product.url, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(product.url))
                                    context.startActivity(intent)
                                }) { Text("Buka Shopee") }
                                OutlinedButton(onClick = {
                                    products.remove(product)
                                    persist()
                                }) { Text("Hapus") }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Versi awal: menyimpan produk dan harga target secara lokal. Pemantauan harga langsung, alarm terjadwal, dan checkout otomatis belum tersedia.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
