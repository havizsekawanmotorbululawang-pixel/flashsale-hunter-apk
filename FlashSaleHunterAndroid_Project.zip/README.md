# FlashSale Hunter — Android starter project

Aplikasi pendamping berburu Flash Sale. Fitur saat ini:
- Menambahkan produk incaran dengan URL Shopee dan harga target
- Menyimpan daftar produk secara lokal pada perangkat
- Membuka tautan produk melalui aplikasi/browser
- Menghapus produk dari daftar

Belum tersedia:
- Pemantauan harga langsung (memerlukan sumber data resmi/diizinkan)
- Pengingat Flash Sale terjadwal
- Pembelian otomatis

## Cara membangun APK
1. Pasang Android Studio pada komputer.
2. Buka folder `FlashSaleHunterAndroid` sebagai proyek.
3. Izinkan Gradle melakukan sinkronisasi dan mengunduh dependensi.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke HP Android, lalu instal. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

## Catatan
- Proyek menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose, dan compile SDK 35.
- Ini adalah kode sumber proyek, bukan file APK yang sudah dikompilasi.
- Jangan masukkan kata sandi Shopee ke aplikasi pihak ketiga. Pembelian dan verifikasi tetap dilakukan di Shopee.
